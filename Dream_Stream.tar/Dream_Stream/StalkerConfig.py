from Components.config import config, getConfigListEntry, ConfigText
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import SCOPE_CONFIG, resolveFilename, pathExists, createDir, fileExists
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Log import Log
import os

from StalkerChannels import StalkerChannelSelection
from stalker import Identity
from api import Stalker, NB_OF_PORTALS

# Nouveau chemin pour le fichier stalker.conf
STALKER_CONF_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Dream_Stream/Servers/stalker.conf"

class StalkerConfig(Screen, ConfigListScreen):
    skin = """
        <screen name="StalkerConfig" position="center,center" size="1600,1000" backgroundColor="#cc0c7c" title="Dream_Stream Configuration">
            <!-- TITRE PORTALS LIST -->
            <widget name="title_label" position="center,30" size="1200,80" font="Regular;50" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="transparent" transparent="1" zPosition="2" />
            
            <!-- BOUTONS EN BAS -->
            <ePixmap pixmap="skin_default/buttons/red.png" position="100,920" size="300,60" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="450,920" size="300,60" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/yellow.png" position="800,920" size="300,60" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/blue.png" position="1150,920" size="300,60" alphatest="on" />
            
            <widget source="key_red" render="Label" position="100,920" zPosition="1" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget source="key_green" render="Label" position="450,920" zPosition="1" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
            <widget source="key_yellow" render="Label" position="800,920" zPosition="1" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
            <widget source="key_blue" render="Label" position="1150,920" zPosition="1" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
            
            <eLabel position="50,120" size="1500,2" backgroundColor="white" />
            <widget name="config" position="100,140" size="1400,750" scrollbarMode="showOnDemand" enableWrapAround="1"/>
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session)
        self.setTitle(_("Dream_Stream Configuration"))

        # LABEL TITRE - CORRECTION: Utiliser Label au lieu de StaticText
        from Components.Label import Label
        self["title_label"] = Label(_("Portals List"))
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Edit"))
        self["key_blue"] = StaticText(_("Load Portals"))

        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "VirtualKeyboardActions"],
                                         {
                                             "red": self.keyCancel,
                                             "green": self.save,
                                             "yellow": self.keyYellow,
                                             "blue": self.keyBlue,
                                             "save": self.keySave,
                                             "cancel": self.keyCancel,
                                             "ok": self.ok,
                                             "showVirtualKeyboard": self.KeyText,
                                         }, -2)
        self.api = Stalker()
        self.loadPortals()

    def keyYellow(self):
        if self["config"].getCurrentIndex() < NB_OF_PORTALS:
            self.KeyText()

    def keyBlue(self):
        self.session.openWithCallback(self.getPortals, MessageBox, _("Install Dream_Stream config?"))

    def VirtualKeyBoardCallback(self, callback=None):
        if callback is not None and len(callback):
            self["config"].getCurrent()[1].setValue(callback)
            self["config"].invalidate(self["config"].getCurrent())
            self.onSave()

    def KeyText(self):
        if self["config"].getCurrentIndex() < NB_OF_PORTALS:
            self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard,
                                          title=self["config"].getCurrent()[0],
                                          text=self["config"].getCurrent()[1].value)

    def getPortals(self, message):
        if message:
            # Utiliser le nouveau chemin
            if fileExists(STALKER_CONF_PATH):
                data = open(STALKER_CONF_PATH, "r").read()
                if len(data):
                    data = data.split('\n')
                    for x in data:
                        y = x.split(' ')
                        if len(y) == 3:
                            if y[0] == 'portal':
                                config.stalker_client.portals[int(y[1])].portal.value = y[2]
                                config.stalker_client.portals[int(y[1])].save()
                    config.stalker_client.save()
                    self.loadPortals()
            else:
                self.session.open(MessageBox, _("Failed to read %s not found" % STALKER_CONF_PATH))

    def loadPortals(self):
        self.list = []
        self.name = []
        for x in range(NB_OF_PORTALS):
            self.name.append(ConfigText(default=config.stalker_client.portals[x].portal.value, fixed_size=False))
            if config.stalker_client.portal.value == x:
                self.list.append(getConfigListEntry(">> " + _("Portal URL") + (" %d" % (x + 1)), self.name[x]))
            else:
                self.list.append(getConfigListEntry(_("Portal URL") + (" %d" % (x + 1)), self.name[x]))
        self["config"].list = self.list

    def ok(self):
        if self["config"].getCurrentIndex() < NB_OF_PORTALS:
            self.onSave()
            self.session.openWithCallback(self.confirmationResult, MessageBox, _("Set this portal as default?"))

    def confirmationResult(self, result):
        if result:
            config.stalker_client.portal.value = self["config"].getCurrentIndex()
            config.stalker_client.portal.save()
            config.stalker_client.save()
            self.loadPortals()
            f = resolveFilename(SCOPE_CONFIG, "%s/%s" % ("stalker", "genres"))
            if fileExists(f):
                import os
                os.remove(f)
            self.api.reset()
            self.login()

    def login(self):
        Log.i("Reload Dream_Stream")
        if not self.onLoginSuccess in StalkerChannelSelection.stalker.onLoginSuccess:
            StalkerChannelSelection.stalker.onLoginSuccess.append(self.onLoginSuccess)
        try:
            mac = config.stalker_client.portals[config.stalker_client.portal.value].portal.value.split('mac=')[-1]
        except:
            mac = '00:1A:79:3D:8F:01'
        StalkerChannelSelection.stalker.login(Identity(mac, "en_GB.utf8", "Europe/Berlin"))

    def onLoginSuccess(self):
        Log.w(StalkerChannelSelection.stalker.reload())
        StalkerChannelSelection.stalker.onLoginSuccess.remove(self.onLoginSuccess)

    def onSave(self):
        for x in range(NB_OF_PORTALS):
            config.stalker_client.portals[x].portal.value = self.name[x].value
            config.stalker_client.portals[x].save()
        config.stalker_client.save()

    def save(self):
        self.onSave()
        self.close()
