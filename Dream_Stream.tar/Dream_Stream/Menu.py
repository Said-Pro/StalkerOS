# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Button import Button
from skin import parseColor
# ---------- FIX : import pour log + traceback ----------
from Tools.Log import Log
import traceback
# -------------------------------------------------------

# Imports des écrans que tu veux ouvrir
from StalkerConfig import StalkerConfig
from StalkerChannels import StalkerChannelSelection

class Dream_StreamMainMenu(Screen):
    skin = """
    <screen name="Dream_StreamMainMenu" position="center,center" size="1600,1000" backgroundColor="#0a0af0" title="Dream_Stream by Said M.S">
        <!-- BACKGROUND DECORATIF -->
        <eLabel position="center,140" size="1000,3" backgroundColor="#ffffff" zPosition="1" />
        
        <!-- TITRE PRINCIPAL AVEC STYLE -->
        <widget name="title_label" position="center,50" size="1200,120" font="Regular;60" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="transparent" transparent="1" zPosition="2" />
        
        <!-- SOUS-TITRE -->
        <widget name="subtitle_label" position="center,180" size="1000,60" font="Regular;30" halign="center" valign="center" foregroundColor="#e0e0e0" backgroundColor="transparent" transparent="1" zPosition="2" />
        
        <eLabel position="center,250" size="800,3" backgroundColor="#ffffff" zPosition="1" />
        
        <!-- BOUTONS -->
        <widget name="button_portals" position="center,350" size="600,100" font="Regular;40" halign="center" valign="center" backgroundColor="#ed13d4" transparent="0" zPosition="1" />
        <widget name="button_channels" position="center,500" size="600,100" font="Regular;40" halign="center" valign="center" backgroundColor="#ed13d4" transparent="0" zPosition="1" />
        
        <!-- ÉLÉMENTS EN BAS - BOUTON EXIT ET VERSION -->
        <widget name="key_red" position="100,900" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#ff0000" transparent="0" zPosition="1" />
        <widget name="version_label" position="1350,900" size="200,60" font="Regular;30" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="transparent" transparent="1" zPosition="1" />
    </screen>"""

    def __init__(self, session):
        # ---------- FIX : try/except global ----------
        try:
            Screen.__init__(self, session)
            self.session = session

            # LABELS
            self["title_label"] = Label(_("MAIN MENU"))
            self["subtitle_label"] = Label(_("Dream Stream IPTV Manager"))
            self["version_label"] = Label(_("Version 1.0"))
            
            self["button_portals"] = Label(_("Portals Configuration"))
            self["button_channels"] = Label(_("Channels Configuration"))
            self["key_red"] = Label(_("EXIT"))

            self.selected = 0          # 0 = portals, 1 = channels

            self.onShown.append(self.updateHighlight)

            self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"],
                                        {
                                            "ok": self.execSelected,
                                            "cancel": self.close,
                                            "up": self.moveUp,
                                            "down": self.moveDown,
                                            "red": self.close  # Action pour le bouton rouge EXIT
                                        })
        except Exception:
            Log.w("Dream_StreamMainMenu crash : " + traceback.format_exc())
            self.close()

    # --------------------------------------------------
    # Navigation
    # --------------------------------------------------
    def moveUp(self):
        self.selected = 0
        self.updateHighlight()

    def moveDown(self):
        self.selected = 1
        self.updateHighlight()

    # --------------------------------------------------
    # Mise à jour de la surbrillance
    # --------------------------------------------------
    def updateHighlight(self):
        # ---------- FIX : try/extern ----------
        try:
            white = parseColor("white")
            red   = parseColor("red")
            gold  = parseColor("#ffd700")  # Couleur or pour la sélection
            
            if self["button_portals"].instance:
                self["button_portals"].instance.setForegroundColor(gold if self.selected == 0 else white)
            if self["button_channels"].instance:
                self["button_channels"].instance.setForegroundColor(gold if self.selected == 1 else white)
        except Exception:
            Log.w("updateHighlight crash : " + traceback.format_exc())

    # --------------------------------------------------
    # Validation
    # --------------------------------------------------
    def execSelected(self):
        if self.selected == 0:
            self.session.open(StalkerConfig)
        else:
            self.session.open(StalkerChannelSelection)